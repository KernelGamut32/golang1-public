package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

var ops = map[rune]func(int, int) int{
	'+': add,
	'-': sub,
	'*': mul,
	'/': div,
}

func main() {
	scanner := bufio.NewScanner(os.Stdin)
	var op rune
	var op1, op2 int

	for scanner.Scan() {
		line := scanner.Text()
		if line == "quit" {
			return
		}
		line = strings.Replace(line, " ", "", -1)
		if n, _ := fmt.Sscanf(line, "%d%c%d", &op1, &op, &op2); n == 3 {
			if f, present := ops[op]; present {
				fmt.Println(f(op1, op2))
			} else {
				fmt.Printf("bad operator: %q\n", op)
			}
		} else {
			fmt.Println("bad line:", line)
		}
	}
}

func add(op1, op2 int) int {
	return op1 + op2
}

func sub(op1, op2 int) int {
	return op1 - op2
}

func mul(op1, op2 int) int {
	return op1 * op2
}

func div(op1, op2 int) int {
	return op1 / op2
}
