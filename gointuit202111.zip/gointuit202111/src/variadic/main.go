package main

import "fmt"

func main() {
	in := make([]int, 0)
	var input int
	for i := 0; i < 5; i++ {
		fmt.Printf("Enter number %d: ", i+1)
		fmt.Scanln(&input)
		in = append(in, input)
	}
	fmt.Println(in)

	tests := [][]int{
		{1, 2, 3},
		{4, 5},
		{},
	}
	for _, test := range tests {
		fmt.Println(test, product(test...))
	}
}

func product(nums ...int) int {
	result := 1
	for _, num := range nums {
		result *= num
	}
	return result
}
