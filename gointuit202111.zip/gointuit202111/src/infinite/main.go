package main

import (
	"fmt"
	"strconv"
)

func main() {
	fmt.Println("You entered", getint())
}

func getint() int {
	var str string

	for {
		fmt.Print("Enter an integer: ")
		// fmt.Scanf("%s", &str)
		fmt.Scanln(&str)
		if num, err := strconv.Atoi(str); err != nil {
			fmt.Println("...not an integer, please try again")
		} else {
			return num
		}
	}
}
