package utility

func Scale(op1 int) int {
	return op1 * factor
}
