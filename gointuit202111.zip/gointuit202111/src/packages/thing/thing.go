package thing

// thing type is NOT exported
type thing struct {
	val int
}

// this variable is NOT exported
var privateThing thing

func ReadThing() int {
	return privateThing.val
}

func WriteThing(val int) {
	privateThing.val = val
}
