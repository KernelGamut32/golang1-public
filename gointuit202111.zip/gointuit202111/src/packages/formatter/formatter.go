package formatter

import (
	"fmt"

	"github.com/KernelGamut32/golab/src/packages/internal"
)

func Format(num int) string {
	return fmt.Sprintf("%s: The number is %d\n", internal.Prefix, num)
}
