package subformatter

import (
	"fmt"

	"github.com/KernelGamut32/golab/src/packages/internal"
)

func SubFormat(num int) string {
	return fmt.Sprintf("%s: The number is %d\n", internal.Prefix, num)
}
