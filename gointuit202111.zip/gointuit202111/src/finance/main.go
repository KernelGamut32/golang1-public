package main

import (
	"fmt"

	"github.com/KernelGamut32/golab/src/packages/banking"
)

func main() {
	bankAccount1, err := banking.OpenNewAccount("Melissa", "Testing", 200.0)
	if err != nil {
		fmt.Println("Error opening bank account", err)
		return
	}

	bankAccount2, err := banking.OpenNewAccount("Bob", "Roberts", 175.0)
	if err != nil {
		fmt.Println("Error opening bank account", err)
		return
	}

	fmt.Printf("%s has a balance of $%.2f\n", bankAccount1.GetFullName(), bankAccount1.CheckBalance())
	fmt.Printf("%s has a balance of $%.2f\n", bankAccount2.GetFullName(), bankAccount2.CheckBalance())

	if res, err := bankAccount1.Deposit(10); err != nil {
		fmt.Println(err)
	} else {
		fmt.Printf("Balance after deposit is $%.2f\n", res)
	}

	if res, err := bankAccount2.Withdraw(50.0); err != nil {
		fmt.Println(err)
	} else {
		fmt.Printf("Balance after deposit is $%.2f\n", res)
	}

	fmt.Printf("%s has a balance of $%.2f\n", bankAccount1.GetFullName(), bankAccount1.CheckBalance())
	fmt.Printf("%s has a balance of $%.2f\n", bankAccount2.GetFullName(), bankAccount2.CheckBalance())

	jointAccount := bankAccount1.CreateJointAccount(bankAccount2)
	fmt.Printf("%s has a balance of $%.2f\n", jointAccount.GetFullName(), jointAccount.CheckBalance())
}
