package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	val := 1
	rand.Seed(time.Now().UnixNano())

	defer func() {
		fmt.Println("deferred - cleanup here!")
		if r := recover(); r == "error - negative number" {
			fmt.Println("recovering from panic")
		} else if r != nil {
			panic(r)
		}
	}()

	for {
		fmt.Print("Enter an integer: ")
		fmt.Scanf("%d", &val)
		if val == 0 {
			break
		}
		if val < 0 {
			panic("error - negative number")
			// fmt.Println("error - negative number")
			// return
		}
		if rand.Float64() <= 0.1 {
			panic("random")
		}
	}
	fmt.Println("exiting")
}
