package main

import (
	"fmt"
	"math"
)

func main() {
	r := 3.1987
	a, c := circleinfo(r)
	fmt.Printf("Radius = %.2f, Area = %.2f, Circumference = %.2f\n", r, a, c)
}

func circleinfo(r float64) (float64, float64) {
	return math.Pi * r * r, 2 * math.Pi * r
}
