package main

import (
	"fmt"
	"strings"
)

var translations = map[rune]int{
	'M': 1000,
	'D': 500,
	'C': 100,
	'L': 50,
	'X': 10,
	'V': 5,
	'I': 1,
}

func main() {
	var number string

	fmt.Print("Enter a Roman number: ")
	fmt.Scanln(&number)
	fmt.Printf("%s is equivalent to %d\n", number, translate(strings.ToUpper(number)))
}

func translate(number string) int {
	arabicvals := make([]int, len(number)+1)
	for index, digit := range number {
		if value, present := translations[digit]; present {
			arabicvals[index] = value
		} else {
			fmt.Printf("bad digit: %c\n", digit)
		}
	}
	fmt.Println("Before:", arabicvals)
	total := 0
	for index := 0; index < len(number); index++ {
		if arabicvals[index] < arabicvals[index+1] {
			arabicvals[index] = -arabicvals[index]
		}
		total += arabicvals[index]
	}
	fmt.Println("After:", arabicvals)
	return total
}
