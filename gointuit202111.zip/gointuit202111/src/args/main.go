package main

import (
	"fmt"
	"os"
	"strconv"
)

func main() {
	var num1 int
	var err error

	if len(os.Args) < 3 {
		fmt.Println("Usage is: <program> <arg1> <arg2>")
		return
	}

	if num1, err = strconv.Atoi(os.Args[1]); err != nil {
		fmt.Println(err)
	}
	num2, _ := strconv.Atoi(os.Args[2])
	fmt.Println(num1 + num2)
}
