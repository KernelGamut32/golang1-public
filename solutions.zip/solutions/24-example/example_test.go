package main

func ExampleMMandP() {
	MakeMapAndPrint("This is a test of maps and ordering")
	// Unordered output:
	// This
	// is
	// a
	// test
	// of
	// maps
	// and
	// ordering
}
